input4MIPs-cmor-tables
========

  CMOR tables for input4MIPs


Description
--------

  * Contents of this directory should be updated
    with the contents of "Tables" directory
    in the repogitory of "input4MIPs-cmor-tables"
    at <https://github.com/PCMDI/input4MIPs-cmor-tables>.

  * For a new version JRA55-do, create an entry in
    "input4MIPs_CV.json.MRI-JRA55-do-all-versions",
    and then copy/paste that entry in "input4MIPs_CV.json".


Contact
--------

  * Hiroyuki TSUJINO (JMA-MRI)
